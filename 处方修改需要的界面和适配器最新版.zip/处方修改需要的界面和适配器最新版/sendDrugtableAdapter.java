package sixsixsix.humian.com.chatdemotest.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chuangyuan.HeartFamous.R;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import sixsixsix.humian.com.chatdemotest.Bean.DrugsBean;

/**
 * Created by Supreme on 2018/8/28.
 * 发送处方界面药品适配器
 */

public class sendDrugtableAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    List<DrugsBean.DataBean> sendDrugBeanList;
    public Context mContext;

    public sendDrugtableAdapter(Context context, List<DrugsBean.DataBean> sendDrugBeanList) {
        this.sendDrugBeanList = sendDrugBeanList;
        this.mContext = context;
    }

    public void setData(List<DrugsBean.DataBean> list) {
        if (list != null) {
            sendDrugBeanList.clear();  //清除掉里面所有的数据
            sendDrugBeanList.addAll(list);
            notifyDataSetChanged();   //刷新内容
        }
    }

    /**
     * 定义一个接口   ----------------------------------------
     */
    public sendDrugtableAdapter.OnItemClickListener onItemClickListener;

    /**
     * 点击事件接口
     */
    public interface OnItemClickListener {
        //        传入数据
        void click(DrugsBean.DataBean dataBean, int position);  //点击事件接口
    }

    /**
     * 设置接口
     **/
    public void setOnItemClickListener(sendDrugtableAdapter.OnItemClickListener mOnItemClickListener) {
        this.onItemClickListener = mOnItemClickListener;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_drugs, parent, false);
        sendDrugtableAdapter.MydtHolder mydtHolder = new sendDrugtableAdapter.MydtHolder(view);
        return mydtHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final DrugsBean.DataBean drugs = sendDrugBeanList.get(position);
        ((MydtHolder) holder).yaopin_name.setText(drugs.getTradeName() + "");
        ((MydtHolder) holder).Drug_quantity.setText(drugs.getMcount() + "");
        ((MydtHolder) holder).Drug_specifications.setText(drugs.getSpecification() + "");
        ((MydtHolder) holder).usage_and_dosage.setText(drugs.getMfrequency() + "");
        ((MydtHolder) holder).yongyao_age.setText(drugs.getMdays() + "");
        try {
            ((MydtHolder) holder).drug_pricees.setText(String.valueOf(Integer.parseInt(drugs.getMcount()) * Integer.parseInt(drugs.getQty())) + "");
        } catch (Exception e) {
            Log.e("tag", "数据转化异常");
        }
//        ((DrugAdapter.MygsHolder)holder).drugsLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                标记错误
//                onItemClickListener.click(drugs,position);
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return sendDrugBeanList.size();
    }

    class MydtHolder extends RecyclerView.ViewHolder {
        LinearLayout drugsLayout;
        TextView yaopin_name, Drug_quantity, Drug_specifications, usage_and_dosage, yongyao_age, yongyao_ci, drug_pricees;

        public MydtHolder(View itemView) {
            super(itemView);
//            drugsLayout =(LinearLayout) itemView.findViewById(R.id.drugs_enter_layout);
            yaopin_name = (TextView) itemView.findViewById(R.id.yaopin_name);
            Drug_quantity = (TextView) itemView.findViewById(R.id.Drug_quantity);
            Drug_specifications = (TextView) itemView.findViewById(R.id.Drug_specificationess);
            usage_and_dosage = (TextView) itemView.findViewById(R.id.usage_and_dosage);
            yongyao_age = (TextView) itemView.findViewById(R.id.yongyao_age);

//            yongyao_ci=(TextView) itemView.findViewById(R.id.yongyao_ci);
            drug_pricees = (TextView) itemView.findViewById(R.id.Drug_prices);

        }

    }
}
