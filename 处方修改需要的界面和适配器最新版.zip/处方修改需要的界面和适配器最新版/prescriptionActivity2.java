package sixsixsix.humian.com.chatdemotest.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.chuangyuan.HeartFamous.R;
import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import http.BaseCallBack;
import http.BaseOkHttpClient;
import http.LogUtil;
import http.OkHttpData;
import okhttp3.Call;
import sixsixsix.humian.com.chatdemotest.Bean.AddPrescriptionResult;
import sixsixsix.humian.com.chatdemotest.Bean.DrugsBean;
import sixsixsix.humian.com.chatdemotest.adapter.DrugtableAdapter;


/*
2018.8.22开处方页面
 */
public class prescriptionActivity2 extends AppCompatActivity implements View.OnClickListener {
    TextView Name, Sex, Age, exit, start_drug;
    RelativeLayout Rv_Diagnosis;
    RecyclerView recyclerView;
    Button insert_prescription;
    DrugtableAdapter drugtableAdapter;
    List<DrugsBean.DataBean> mList = new ArrayList<>();
    DrugsBean.DataBean drugs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription2);
        EventBus.getDefault().register(this);
        Name = (TextView) findViewById(R.id.name);
        Sex = (TextView) findViewById(R.id.sex);
        Age = (TextView) findViewById(R.id.age);
        exit = (TextView) findViewById(R.id.prescription_exit);
        start_drug = (TextView) findViewById(R.id.tv_start_drug);
        Rv_Diagnosis = (RelativeLayout) findViewById(R.id.rv_Diagnosis);
        insert_prescription = (Button) findViewById(R.id.insert_prescription);
        recyclerView = (RecyclerView) findViewById(R.id.prescription_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        drugtableAdapter = new DrugtableAdapter(this, mList);
        recyclerView.setAdapter(drugtableAdapter);

        exit.setOnClickListener(this);
        Rv_Diagnosis.setOnClickListener(this);
        insert_prescription.setOnClickListener(this);
        start_drug.setOnClickListener(this);
//        getData();

    }

    public void addPrescriptionl(String loginPhone, String doctorLoginPhone, String userLoginPhone,
                                 String patientId, String patientName, String patientGender,
                                 String patientAge, String diagnosis, String doctorName, String money,
                                 List<DrugsBean.DataBean> list) {
        String json = new Gson().toJson(list);
        BaseOkHttpClient.newBuilder()
                .post()
                .addParam("loginPhone", loginPhone)
                .addParam("doctorLoginPhone", doctorLoginPhone)
                .addParam("userLoginPhone", userLoginPhone)
                .addParam("patientId", patientId)
                .addParam("patientName", patientName)
                .addParam("patientGender", patientGender)
                .addParam("patientAge", patientAge)
                .addParam("diagnosis", diagnosis)
                .addParam("doctorName", doctorName)
                .addParam("money", money)
                // 处方json
                .addParam("drugsData", json)
                .url(OkHttpData.addPrescriptionl)
                .build()
                .enqueue(new BaseCallBack<AddPrescriptionResult>() {
                    @Override
                    public void onSuccess(AddPrescriptionResult o) {
                        if (o != null) {
                            if (o.isSuccess()) {
                                setResult(RESULT_OK, new Intent().putExtra("objectId", o.getId()));
                                finish();
                            }
                        }
                    }

                    @Override
                    public void onError(int code) {
                        LogUtil.d("........................错误.............................");
                    }

                    @Override
                    public void onFailure(Call call, IOException e) {

                    }
                });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.prescription_exit://退出界面
                finish();
                break;
            case R.id.rv_Diagnosis://诊断结果界面
                Intent intent = new Intent(prescriptionActivity2.this, RvdiagnosisActivity.class);
                startActivity(intent);
                break;
            case R.id.insert_prescription://添加药品

                Intent insert = new Intent(prescriptionActivity2.this, DrugStorageActivity.class);
                startActivity(insert);

                break;
            case R.id.tv_start_drug:
                LogUtil.v("---------------drug------------------");
                addPrescriptionl("1565463123", "12312313", "12313132", "123123131", "123123131",
                        "3432", "232", "patientName", "doctorName", "11.11", mList);
                //        new出EaseChatFragment或其子类的实例

//                startActivity(new Intent(prescriptionActivity2.this,ChatActivity.class));

                break;
            default:
                break;
        }


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(DrugsBean.DataBean message) {
        message.setLatestPrice(message.getVIPPrice());
        message.setMcountunit(message.getMcount());
        LogUtil.i("prescriptionActivity2");
        LogUtil.v(message.toString());
        mList.add(message);
        drugtableAdapter.notifyDataSetChanged();
        drugs = message;
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }
}