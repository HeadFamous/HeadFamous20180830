package sixsixsix.humian.com.chatdemotest.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.chuangyuan.HeartFamous.R;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import http.BaseCallBack;
import http.BaseOkHttpClient;
import http.LogUtil;
import http.OkHttpData;
import okhttp3.Call;
import sixsixsix.humian.com.chatdemotest.Bean.DrugsBean;
import sixsixsix.humian.com.chatdemotest.Bean.GetPrescription;
import sixsixsix.humian.com.chatdemotest.adapter.DrugtableAdapter;
import sixsixsix.humian.com.chatdemotest.adapter.sendDrugtableAdapter;

/**
 * Created by Supreme on 2018/8/9.
 * 发给患者的处方单
 */
public class prescriptionAcitvity extends AppCompatActivity {
    //    private RelativeLayout myView;
    private TextView Hospital_name; // 医院名称
    private TextView patient_Id; // 患者编号
    private TextView chufang_id; // 处方编号
    private TextView patient_name; // 患者姓名
    private TextView sex;// 性别
    private TextView age;// 年龄
    private TextView address;// 地址
    private TextView data;// 开局日期
    private TextView telphone; // 手机
    private TextView results;// 诊断结果
    private TextView dosage_drugs; // 用药用量
    private TextView doctor_payment; // 医生落款
    private TextView Review_doctor;// 审核医师
    private TextView Dispensing_doctor; // 调配药师
    private TextView Check_doctor;//核对发药药师
    RecyclerView recyclerViewdrugs;
    sendDrugtableAdapter sendDrugtableAdapter;
    DrugsBean.DataBean drugs2;
    List<DrugsBean.DataBean> mList2 = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        开具药品视图
//        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);

//        recyclerViewdrugs.setLayoutManager(linearLayoutManager);
//        recyclerViewdrugs.setAdapter(sendDrugtableAdapter);
//        sendDrugtableAdapter= new sendDrugtableAdapter(this, mList2);
//        recyclerViewdrugs.setAdapter(sendDrugtableAdapter);
        initView();
        getPrescriptionl(getIntent().getIntExtra("objectId", 0));
    }


    // 上获得处方单数据
    public void getPrescriptionl(int id) {
        BaseOkHttpClient.newBuilder()
                .post()
                .addParam("id", id)
                .url(OkHttpData.getPrescriptionl)
                .build()
                .enqueue(new BaseCallBack<GetPrescription>() {
                    @Override
                    public void onSuccess(GetPrescription o) {
                        if (o != null) {
                            GetPrescription.HospitalBean hospitalBean = o.getHospital().get(0);
                            GetPrescription.DrugDetailBean drugDetailBean = o.getDrugDetail().get(0);
//                            Hospital_name.setText(o.getHospital().get(0).getTradeName());
//                            patient_Id.setText(String.valueOf(hospitalBean.getPatientId()));
//                            chufang_id.setText(String.valueOf(drugDetailBean.getPrescriptionId()));
//                            patient_name.setText(drugDetailBean.getPatientName());
                            sex.setText(drugDetailBean.getPatientGender() == 0 ? "男" : "女");
                            age.setText(String.valueOf(drugDetailBean.getPatientAge()));
                            data.setText(drugDetailBean.getCreatedTime());
//                            telphone.setText(drugDetailBean.getUserLoginPhone());
                            results.setText(drugDetailBean.getDiagnosis());
                            dosage_drugs.setText(hospitalBean.getEachDose() + "/" + hospitalBean.getEachDoseUnit());
//                            doctor_payment.setText(drugDetailBean.getDoctorName());
//                            Review_doctor.setText(drugDetailBean.getDoctorName());
//                            Dispensing_doctor.setText(drugDetailBean.getDoctorName());
//                            Check_doctor.setText(drugDetailBean.getDoctorName());
                        }
                    }

                    @Override
                    public void onError(int code) {
                        LogUtil.d("........................错误.............................");
                    }

                    @Override
                    public void onFailure(Call call, IOException e) {

                    }
                });
    }

    private void initView() {
        patient_name = findViewById(R.id.patient_name);
        recyclerViewdrugs =findViewById(R.id.recycler_drugs2);
        sex = findViewById(R.id.sex);
        age = findViewById(R.id.age);

        data = findViewById(R.id.data);

        results = findViewById(R.id.results);
        dosage_drugs = findViewById(R.id.dosage_drugs);
        doctor_payment = findViewById(R.id.doctor_payment);

    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(DrugsBean.DataBean messageEvent) {
        mList2.add(messageEvent);
        sendDrugtableAdapter.notifyDataSetChanged();

    }


}